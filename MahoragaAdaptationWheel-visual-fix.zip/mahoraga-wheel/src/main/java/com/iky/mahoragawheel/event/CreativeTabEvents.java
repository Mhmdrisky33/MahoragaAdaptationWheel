package com.iky.mahoragawheel.event;

import com.iky.mahoragawheel.MahoragaWheelMod;
import com.iky.mahoragawheel.ModItems;
import net.minecraft.world.item.CreativeModeTabs;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;

@EventBusSubscriber(modid = MahoragaWheelMod.MOD_ID)
public final class CreativeTabEvents {
    private CreativeTabEvents() {}
    @SubscribeEvent
    public static void addToToolsTab(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) event.accept(ModItems.ADAPTATION_WHEEL);
    }
}
