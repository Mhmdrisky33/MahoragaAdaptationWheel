package com.iky.mahoragawheel.client;

import com.iky.mahoragawheel.MahoragaWheelMod;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import org.lwjgl.glfw.GLFW;
import com.mojang.math.Axis;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.neoforged.neoforge.client.event.RenderPlayerEvent;
import com.iky.mahoragawheel.ModItems;
import com.iky.mahoragawheel.network.ClientAdaptationState;

@EventBusSubscriber(modid = MahoragaWheelMod.MOD_ID, value = Dist.CLIENT, bus = EventBusSubscriber.Bus.MOD)
final class ClientSetup {
    static final KeyMapping OPEN_PANEL = new KeyMapping("key.mahoragawheel.open_panel", GLFW.GLFW_KEY_O, "key.categories.mahoragawheel");
    private ClientSetup() {}

    @SubscribeEvent
    static void registerKeys(RegisterKeyMappingsEvent event) { event.register(OPEN_PANEL); }

    @EventBusSubscriber(modid = MahoragaWheelMod.MOD_ID, value = Dist.CLIENT)
    public static final class ClientGameEvents {
        @SubscribeEvent
        public static void onClientTick(ClientTickEvent.Post event) {
            while (OPEN_PANEL.consumeClick()) Minecraft.getInstance().setScreen(new AdaptationScreen());
        }

        @SubscribeEvent
        public static void renderWheel(RenderPlayerEvent.Post event) {
            if (event.getEntity() != Minecraft.getInstance().player || !ClientAdaptationState.isActive()) return;
            var pose = event.getPoseStack();
            pose.pushPose();
            pose.translate(0.0D, 1.62D, 0.0D);
            pose.mulPose(Axis.YP.rotationDegrees((event.getEntity().tickCount + event.getPartialTick()) * 7.0F));
            pose.scale(1.35F, 1.35F, 1.35F);
            Minecraft.getInstance().getItemRenderer().renderStatic(new ItemStack(ModItems.ADAPTATION_WHEEL.get()), ItemDisplayContext.HEAD, event.getPackedLight(), OverlayTexture.NO_OVERLAY, pose, event.getMultiBufferSource(), event.getEntity().level(), event.getEntity().getId());
            pose.popPose();
        }
    }
}
