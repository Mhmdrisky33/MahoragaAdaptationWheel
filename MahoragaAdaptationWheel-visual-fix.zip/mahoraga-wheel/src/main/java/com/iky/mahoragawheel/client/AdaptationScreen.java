package com.iky.mahoragawheel.client;

import com.iky.mahoragawheel.network.ClientAdaptationState;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import java.util.Map;

public class AdaptationScreen extends Screen {
    public AdaptationScreen() { super(Component.literal("Mahoraga — Adaptation")); }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(graphics, mouseX, mouseY, partialTick);
        int left = (this.width - 240) / 2;
        int top = (this.height - 170) / 2;
        graphics.fill(left, top, left + 240, top + 170, 0xE8101018);
        graphics.fill(left, top, left + 240, top + 2, 0xFFFFD500);
        graphics.drawCenteredString(this.font, "MAHORAGA  /  ADAPTATION", this.width / 2, top + 12, 0xFFFFD84A);
        boolean active = ClientAdaptationState.isActive();
        graphics.drawString(this.font, "Wheel: " + (active ? "§aACTIVE" : "§cINACTIVE"), left + 14, top + 34, 0xFFFFFFFF, false);
        graphics.drawString(this.font, "Adaptation progress", left + 14, top + 54, 0xFFE8E8E8, false);
        int y = top + 72;
        {
            Map<String, Integer> values = ClientAdaptationState.progress();
            if (values.isEmpty()) {
                graphics.drawString(this.font, "No damage types recorded yet.", left + 14, y, 0xFFAAAAAA, false);
            } else {
                for (Map.Entry<String, Integer> entry : values.entrySet()) {
                    if (y > top + 140) break;
                    graphics.drawString(this.font, entry.getKey(), left + 14, y, 0xFFFFFFFF, false);
                    graphics.fill(left + 112, y + 1, left + 216, y + 9, 0xFF454545);
                    graphics.fill(left + 112, y + 1, left + 112 + entry.getValue(), y + 9, 0xFFFFD500);
                    graphics.drawString(this.font, entry.getValue() + "%", left + 218, y, 0xFFFFFFFF, false);
                    y += 16;
                }
            }
        }
        graphics.drawCenteredString(this.font, "Press O or ESC to close", this.width / 2, top + 151, 0xFF999999);
        super.render(graphics, mouseX, mouseY, partialTick);
    }

    @Override public boolean isPauseScreen() { return false; }
}
