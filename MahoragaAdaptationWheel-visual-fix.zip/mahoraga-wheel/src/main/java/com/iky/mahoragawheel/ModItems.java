package com.iky.mahoragawheel;

import com.iky.mahoragawheel.item.AdaptationWheelItem;
import net.minecraft.world.item.Item;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;

public final class ModItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MahoragaWheelMod.MOD_ID);
    public static final DeferredItem<Item> ADAPTATION_WHEEL = ITEMS.registerItem("adaptation_wheel", AdaptationWheelItem::new, new Item.Properties().stacksTo(1));
    private ModItems() {}
}
