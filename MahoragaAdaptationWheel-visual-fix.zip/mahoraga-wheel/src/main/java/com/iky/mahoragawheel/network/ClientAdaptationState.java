package com.iky.mahoragawheel.network;

import java.util.LinkedHashMap;
import java.util.Map;

public final class ClientAdaptationState {
    private static boolean active;
    private static final Map<String, Integer> PROGRESS = new LinkedHashMap<>();
    private ClientAdaptationState() {}
    public static boolean isActive() { return active; }
    public static Map<String, Integer> progress() { return Map.copyOf(PROGRESS); }
    public static void update(boolean isActive, String encoded) {
        active = isActive;
        PROGRESS.clear();
        if (encoded == null || encoded.isBlank()) return;
        for (String pair : encoded.split(";")) {
            int split = pair.lastIndexOf('=');
            if (split <= 0) continue;
            try { PROGRESS.put(pair.substring(0, split), Integer.parseInt(pair.substring(split + 1))); }
            catch (NumberFormatException ignored) {}
        }
    }
}
