package com.iky.mahoragawheel;

import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;

@Mod(MahoragaWheelMod.MOD_ID)
public final class MahoragaWheelMod {
    public static final String MOD_ID = "mahoragawheel";

    public MahoragaWheelMod(IEventBus modBus) {
        ModItems.ITEMS.register(modBus);
        ModSounds.SOUNDS.register(modBus);
    }
}
