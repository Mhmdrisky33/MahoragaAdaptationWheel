package com.iky.mahoragawheel.item;

import com.iky.mahoragawheel.data.AdaptationData;
import net.minecraft.network.chat.Component;
import com.iky.mahoragawheel.ModSounds;
import com.iky.mahoragawheel.network.AdaptationSync;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class AdaptationWheelItem extends Item {
    public AdaptationWheelItem(Properties properties) { super(properties); }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        boolean active = !AdaptationData.isActive(player);
        AdaptationData.setActive(player, active);
        if (!level.isClientSide) {
            player.displayClientMessage(Component.literal(active ? "§6[Mahoraga] §eRoda adaptasi aktif." : "§7[Mahoraga] Roda adaptasi nonaktif."), true);
            level.playSound(null, player.blockPosition(), ModSounds.WHEEL_SPIN.get(), SoundSource.PLAYERS, 0.8F, active ? 0.85F : 0.65F);
            AdaptationSync.send(player);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }
}
