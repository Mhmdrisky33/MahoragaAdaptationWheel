package com.iky.mahoragawheel.network;

import com.iky.mahoragawheel.MahoragaWheelMod;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

public record AdaptationSyncPayload(boolean active, String progressData) implements CustomPacketPayload {
    public static final Type<AdaptationSyncPayload> TYPE = new Type<>(ResourceLocation.fromNamespaceAndPath(MahoragaWheelMod.MOD_ID, "adaptation_sync"));
    public static final StreamCodec<RegistryFriendlyByteBuf, AdaptationSyncPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.BOOL, AdaptationSyncPayload::active,
            ByteBufCodecs.STRING_UTF8, AdaptationSyncPayload::progressData,
            AdaptationSyncPayload::new
    );
    @Override public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
