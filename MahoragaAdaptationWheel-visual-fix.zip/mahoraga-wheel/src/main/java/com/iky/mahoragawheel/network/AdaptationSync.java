package com.iky.mahoragawheel.network;

import com.iky.mahoragawheel.data.AdaptationData;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.PacketDistributor;
import net.minecraft.world.entity.player.Player;

public final class AdaptationSync {
    private AdaptationSync() {}
    public static void send(Player player) {
        if (!(player instanceof ServerPlayer serverPlayer)) return;
        StringBuilder encoded = new StringBuilder();
        AdaptationData.snapshot(player).forEach((key, value) -> {
            if (!encoded.isEmpty()) encoded.append(';');
            encoded.append(key.replace(";", "_").replace("=", "_")).append('=').append(value);
        });
        PacketDistributor.sendToPlayer(serverPlayer, new AdaptationSyncPayload(AdaptationData.isActive(player), encoded.toString()));
    }
}
