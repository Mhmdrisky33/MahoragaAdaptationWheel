package com.iky.mahoragawheel;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

public final class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(Registries.SOUND_EVENT, MahoragaWheelMod.MOD_ID);
    public static final DeferredHolder<SoundEvent, SoundEvent> WHEEL_SPIN = SOUNDS.register("wheel_spin", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath(MahoragaWheelMod.MOD_ID, "wheel_spin")));
    private ModSounds() {}
}
