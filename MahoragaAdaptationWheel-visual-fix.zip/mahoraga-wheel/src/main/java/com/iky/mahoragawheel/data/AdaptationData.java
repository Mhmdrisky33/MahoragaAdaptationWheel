package com.iky.mahoragawheel.data;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.player.Player;
import java.util.LinkedHashMap;
import java.util.Map;

/** Persistent per-player adaptation progress. Progress is keyed by vanilla damage message id. */
public final class AdaptationData {
    private static final String ROOT = "MahoragaAdaptation";
    private static final String ACTIVE = "Active";
    private static final String PROGRESS = "Progress";
    private AdaptationData() {}

    private static CompoundTag root(Player player) {
        CompoundTag persistent = player.getPersistentData();
        if (!persistent.contains(ROOT)) persistent.put(ROOT, new CompoundTag());
        return persistent.getCompound(ROOT);
    }

    public static boolean isActive(Player player) { return root(player).getBoolean(ACTIVE); }
    public static void setActive(Player player, boolean active) { root(player).putBoolean(ACTIVE, active); }

    public static int getProgress(Player player, String damageId) {
        return root(player).getCompound(PROGRESS).getInt(damageId);
    }

    public static int addProgress(Player player, String damageId, int amount) {
        CompoundTag root = root(player);
        CompoundTag progress = root.getCompound(PROGRESS);
        int next = Math.min(100, progress.getInt(damageId) + Math.max(1, amount));
        progress.putInt(damageId, next);
        root.put(PROGRESS, progress);
        return next;
    }

    public static Map<String, Integer> snapshot(Player player) {
        CompoundTag tag = root(player).getCompound(PROGRESS);
        Map<String, Integer> values = new LinkedHashMap<>();
        for (String key : tag.getAllKeys()) values.put(key, tag.getInt(key));
        return values;
    }
}
