package com.iky.mahoragawheel.network;

import com.iky.mahoragawheel.MahoragaWheelMod;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;

@EventBusSubscriber(modid = MahoragaWheelMod.MOD_ID, bus = EventBusSubscriber.Bus.MOD)
public final class NetworkHandler {
    private NetworkHandler() {}
    @SubscribeEvent
    public static void register(RegisterPayloadHandlersEvent event) {
        event.registrar("1").playToClient(AdaptationSyncPayload.TYPE, AdaptationSyncPayload.STREAM_CODEC,
                (payload, context) -> context.enqueueWork(() -> ClientAdaptationState.update(payload.active(), payload.progressData())));
    }
}
