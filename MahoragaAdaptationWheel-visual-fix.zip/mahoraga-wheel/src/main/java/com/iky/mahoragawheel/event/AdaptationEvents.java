package com.iky.mahoragawheel.event;

import com.iky.mahoragawheel.MahoragaWheelMod;
import com.iky.mahoragawheel.data.AdaptationData;
import com.iky.mahoragawheel.network.AdaptationSync;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Player;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;

@EventBusSubscriber(modid = MahoragaWheelMod.MOD_ID)
public final class AdaptationEvents {
    private AdaptationEvents() {}

    @SubscribeEvent
    public static void onIncomingDamage(LivingIncomingDamageEvent event) {
        if (!(event.getEntity() instanceof Player player) || player.level().isClientSide) return;
        if (!AdaptationData.isActive(player)) return;

        String damageId = event.getSource().getMsgId();
        int before = AdaptationData.getProgress(player, damageId);
        int progress = AdaptationData.addProgress(player, damageId, 20);

        if (before < 100 && progress >= 100) {
            player.displayClientMessage(Component.literal("§6✦ ADAPTATION COMPLETE: §e" + damageId), true);
            player.level().playSound(null, player.blockPosition(), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 0.9F, 1.15F);
        } else if (progress < 100) {
            player.displayClientMessage(Component.literal("§6Mahoraga §7» §e" + damageId + " §f" + progress + "%"), true);
        }

        if (before >= 100) {
            event.setAmount(event.getAmount() * 0.25F);
        }
        AdaptationSync.send(player);
    }
}
